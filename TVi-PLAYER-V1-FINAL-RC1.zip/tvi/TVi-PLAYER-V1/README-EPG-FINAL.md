# TVi PLAYER V1 — EPG stage

Added XMLTV import with local Room caching, database migration 2→3, current/next guide screen, HTTP/HTTPS EPG download, and TV-first landscape UI.

EPG programme rows are keyed by XMLTV channel id and start timestamp. IPTV video traffic remains direct to the provider.
