# TVi PLAYER V1 — Final QA / Release Candidate

Version: 1.0.0-rc1

## Architecture
- TV-first Android application
- Landscape-first / remote-first navigation
- Standard Player: M3U + Xtream
- OATEC Premium: activation/configuration control plane
- Direct IPTV playback; OATEC is not a video proxy
- Room persistence for playlists, channels, history and EPG
- Media3/ExoPlayer playback with primary/backup failover

## Release checks
- [x] Landscape activity configuration
- [x] Android TV LEANBACK launcher category
- [x] Touchscreen not required
- [x] TV banner resource
- [x] Java/Kotlin JVM target 17 declared
- [x] OATEC HTTPS API separated from IPTV provider URLs
- [x] HTTP IPTV providers remain supported by network policy
- [x] M3U / Xtream / EPG modules present
- [x] Movies / Series modules present
- [x] Favorites / history / custom categories present
- [x] OATEC Premium code-only client flow present

## Required external validation before production
1. Build with Android SDK + Gradle/AGP 8.7.3 and JDK 17.
2. Install on a physical Android TV / TV Box.
3. Test 720p, 1080p and 4K displays.
4. Test D-pad only: Up/Down/Left/Right/OK/Back and CH+/CH-.
5. Test M3U HTTP/HTTPS and Xtream HTTP/HTTPS.
6. Test XMLTV EPG with large datasets.
7. Test OATEC activation, heartbeat, logout and device binding against the patched backend.
8. Test stream failure and primary-to-backup failover.
9. Test Arabic RTL and all supported language strings.
10. Run release build and inspect APK/AAB before publishing.

## Important
This repository is a release candidate source package. An APK/AAB must not be considered production-ready until the Android build and device QA above are completed in an environment with the Android SDK installed.
