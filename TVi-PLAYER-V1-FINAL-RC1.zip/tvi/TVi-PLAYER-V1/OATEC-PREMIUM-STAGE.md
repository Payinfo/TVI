# OATEC Premium Stage

This stage adds the real code-only activation flow to both sides.

## Backend
`POST /api/player/activate-by-code`

Request:
```json
{"code":"ABCD-1234","device_id":"...","device_name":"...","platform":"android","app_version":"1.0.0"}
```

The endpoint validates the activation code without requiring customer email, binds it to the first device, creates a player token, and returns subscription/config. Existing `/api/player/activate` remains unchanged for backward compatibility.

## Player
- Sends only activation code plus generated device metadata.
- Stores the player token locally.
- Restores the Premium session on app start using `/api/player/me`.
- Sends heartbeat every 5 minutes.
- Supports logout/revoke.
- Receives primary/backup provider configuration from OATEC.
- OATEC remains control-plane only; video traffic stays between the player and IPTV provider.

## Important
The backend must be deployed before testing the new code-only activation endpoint. The source project is not claimed to be a compiled APK in this environment.
