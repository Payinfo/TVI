# Player Engine stage

- Media3/ExoPlayer controller isolated in `player/PlayerEngine.kt`.
- Primary + optional backup source failover.
- Two bounded reconnect attempts per source.
- Play/pause, mute and channel +/- remote handling.
- PlayerView controller optimized for TV.
- Channel entity now supports `backupStreamUrl`; Room migration 3->4 included.

Build verification requires an Android SDK/Gradle environment; this workspace does not include one.
