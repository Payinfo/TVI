package com.oatec.tviplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.app.Application
import com.oatec.tviplayer.data.content.EpgRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class EpgUiState(val loading:Boolean=false, val count:Int=0, val items:List<com.oatec.tviplayer.data.db.EpgEntity> = emptyList(), val message:String?=null)

class EpgViewModel(app: Application): AndroidViewModel(app) {
    private val repo=EpgRepository(app)
    private val _state=MutableStateFlow(EpgUiState())
    val state:StateFlow<EpgUiState> = _state.asStateFlow()
    fun import(url:String){
        val clean=url.trim(); if(clean.isBlank()) return
        viewModelScope.launch {
            _state.value=EpgUiState(loading=true)
            runCatching { repo.importXmltv(clean) }.onSuccess { n -> _state.value=EpgUiState(count=n,message=if(n==0) "No programmes found" else "Imported $n programmes") }.onFailure { e -> _state.value=EpgUiState(message=e.message ?: "EPG import failed") }
        }
    }
    fun load(){ viewModelScope.launch { _state.value=_state.value.copy(items=repo.current()) } }
}

@Composable
fun EpgScreen(onBack:()->Unit, vm:EpgViewModel = androidx.lifecycle.viewmodel.compose.viewModel()){
    var url by remember { mutableStateOf("") }
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit){vm.load()}
    val fmt=remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Row(Modifier.fillMaxSize().background(Color(7,9,13)).padding(42.dp)){
        Column(Modifier.width(420.dp).fillMaxHeight(),verticalArrangement=Arrangement.spacedBy(14.dp)){
            Text("EPG / TV GUIDE",color=Color.White,fontSize=32.sp)
            Text("Import an XMLTV URL. EPG is cached locally.",color=Color.LightGray)
            OutlinedTextField(url,{url=it},label={Text("XMLTV / EPG URL")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Button(onClick={vm.import(url)},enabled=!state.loading,modifier=Modifier.fillMaxWidth().height(54.dp)){Text(if(state.loading) "Importing…" else "Import EPG")}
            OutlinedButton(onClick=onBack,modifier=Modifier.fillMaxWidth().height(52.dp)){Text("Back")}
            state.message?.let{Text(it,color=if(it.startsWith("Imported")) Color(120,220,150) else Color(255,170,170))}
        }
        Spacer(Modifier.width(36.dp))
        Column(Modifier.weight(1f).fillMaxHeight()){
            Text("Current / next programmes",color=Color.White,fontSize=22.sp)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){
                items(state.items){item->
                    Surface(color=Color(18,22,30),modifier=Modifier.fillMaxWidth()){
                        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                            Text(fmt.format(Date(item.start))+"–"+fmt.format(Date(item.end)),color=Color.LightGray,modifier=Modifier.width(120.dp))
                            Column{Text(item.channelId,color=Color(130,170,220),fontSize=12.sp);Text(item.title,color=Color.White,fontSize=17.sp,maxLines=1);item.description?.takeIf{it.isNotBlank()}?.let{Text(it,color=Color.Gray,fontSize=12.sp,maxLines=1)}}
                        }
                    }
                }
            }
        }
    }
}
