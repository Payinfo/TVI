package com.oatec.tviplayer.data.xtream

import com.oatec.tviplayer.data.playlist.PlaylistSource

object XtreamStreamUrl {
    fun live(source: PlaylistSource, streamId: Int, extension: String = "ts"): String {
        val server = requireNotNull(source.server).trimEnd('/')
        return "$server/live/${requireNotNull(source.username)}/${requireNotNull(source.password)}/$streamId.$extension"
    }
}
