package com.oatec.tviplayer.data.content

import com.oatec.tviplayer.data.playlist.PlaylistSource
import com.oatec.tviplayer.data.xtream.XtreamApi
import com.oatec.tviplayer.data.xtream.XtreamEpisodeResponse
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class ContentRepository {
    private fun api() = Retrofit.Builder()
        .baseUrl("https://localhost/")
        .addConverterFactory(MoshiConverterFactory.create())
        .build().create(XtreamApi::class.java)

    private fun url(s: PlaylistSource) = requireNotNull(s.server).trimEnd('/') + "/player_api.php"
    private fun requireXtream(s: PlaylistSource) {
        require(s.type.name == "XTREAM") { "Movies and Series require an Xtream playlist" }
        require(!s.server.isNullOrBlank() && !s.username.isNullOrBlank() && !s.password.isNullOrBlank()) { "Incomplete Xtream credentials" }
    }

    suspend fun movies(s: PlaylistSource): List<VodMovie> {
        requireXtream(s)
        return api().vodStreams(url(s), s.username!!, s.password!!).mapNotNull { item ->
            item.streamId?.let { id ->
                val ext = item.extension?.ifBlank { "mp4" } ?: "mp4"
                VodMovie(id.toString(), item.name ?: "Untitled", "${s.server!!.trimEnd('/')}/movie/${s.username}/${s.password}/$id.$ext", item.streamIcon, item.backdropPath?.firstOrNull(), item.categoryId, item.plot, item.durationSecs, item.rating?.toDoubleOrNull())
            }
        }
    }

    suspend fun series(s: PlaylistSource): List<VodSeries> {
        requireXtream(s)
        return api().series(url(s), s.username!!, s.password!!).mapNotNull { item ->
            item.seriesId?.let { id -> VodSeries(id.toString(), item.name ?: "Untitled", item.cover, item.backdropPath?.firstOrNull(), item.categoryId, item.plot, item.rating?.toDoubleOrNull()) }
        }
    }

    suspend fun seriesEpisodes(s: PlaylistSource, seriesId: String): List<VodEpisode> {
        requireXtream(s)
        val response = api().seriesInfo(url(s), s.username!!, s.password!!, seriesId)
        return response.episodes.orEmpty().toSortedMap(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE })
            .flatMap { (season, episodes) -> episodes.map { it.toDomain(season, s) } }
    }

    private fun XtreamEpisodeResponse.toDomain(season: String, s: PlaylistSource): VodEpisode {
        val id = requireNotNull(id) { "Episode id missing" }
        val ext = extension?.ifBlank { "mp4" } ?: "mp4"
        return VodEpisode(id, season.toIntOrNull() ?: 0, episodeNum ?: 0, title ?: "Episode ${episodeNum ?: ""}", "${s.server!!.trimEnd('/')}/series/${s.username}/${s.password}/$id.$ext", info?.image, info?.plot, info?.durationSecs)
    }
}
