package com.oatec.tviplayer.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [PlaylistEntity::class, ChannelEntity::class, UserCategoryEntity::class, WatchHistoryEntity::class, EpgEntity::class], version = 4, exportSchema = false)
abstract class PlayerDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    companion object {
        @Volatile private var INSTANCE: PlayerDatabase? = null
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE channels ADD COLUMN isFavorite INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE channels ADD COLUMN userCategoryId TEXT")
                db.execSQL("CREATE TABLE IF NOT EXISTS user_categories (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, sortOrder INTEGER NOT NULL DEFAULT 0, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS watch_history (channelId TEXT NOT NULL PRIMARY KEY, watchedAt INTEGER NOT NULL, position INTEGER NOT NULL DEFAULT 0)")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS epg_programmes (channelId TEXT NOT NULL, start INTEGER NOT NULL, end INTEGER NOT NULL, title TEXT NOT NULL, description TEXT, updatedAt INTEGER NOT NULL, PRIMARY KEY(channelId, start))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_epg_programmes_channelId_start ON epg_programmes(channelId, start)")
            }
        }
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE channels ADD COLUMN backupStreamUrl TEXT")
            }
        }
        fun get(context: Context): PlayerDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, PlayerDatabase::class.java, "tvi_player.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { INSTANCE = it }
        }
    }
}
