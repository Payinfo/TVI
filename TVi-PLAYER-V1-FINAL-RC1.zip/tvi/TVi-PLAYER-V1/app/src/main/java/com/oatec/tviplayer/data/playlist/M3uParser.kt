package com.oatec.tviplayer.data.playlist

/** Robust, streaming-friendly M3U parser for common IPTV attributes. */
object M3uParser {
    fun parse(text: String, providerId: String): List<Channel> {
        val normalized = text.removePrefix("\uFEFF")
        val lines = normalized.lineSequence().map { it.trimEnd('\r') }.iterator()
        val result = ArrayList<Channel>()
        var pending: Map<String, String> = emptyMap()
        var pendingName: String? = null
        var index = 0

        while (lines.hasNext()) {
            val line = lines.next().trim()
            if (line.isEmpty() || line.equals("#EXTM3U", ignoreCase = true)) continue
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val comma = line.indexOf(',')
                val attrsPart = if (comma >= 0) line.substring(0, comma) else line
                pendingName = if (comma >= 0) line.substring(comma + 1).trim() else "Channel"
                pending = parseAttributes(attrsPart)
                continue
            }
            if (!line.startsWith('#')) {
                val name = pending["tvg-name"]?.takeIf { it.isNotBlank() } ?: pendingName ?: "Channel ${index + 1}"
                val idBase = pending["tvg-id"].orEmpty().ifBlank { name.lowercase() }
                result += Channel(
                    id = "$providerId:${idBase.hashCode()}:$index",
                    providerId = providerId,
                    name = name,
                    streamUrl = line,
                    logoUrl = pending["tvg-logo"],
                    groupName = pending["group-title"],
                    tvgId = pending["tvg-id"],
                    tvgName = pending["tvg-name"],
                    country = pending["tvg-country"],
                    language = pending["tvg-language"],
                    number = pending["tvg-chno"]?.toIntOrNull()
                )
                index++
                pending = emptyMap()
                pendingName = null
            }
        }
        return result
    }

    private fun parseAttributes(line: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        val regex = Regex("([A-Za-z][A-Za-z0-9_-]*)\\s*=\\s*(?:\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s]+))")
        regex.findAll(line).forEach { m ->
            val value = m.groupValues[2].ifEmpty { m.groupValues[3].ifEmpty { m.groupValues[4] } }
            out[m.groupValues[1].lowercase()] = value
        }
        return out
    }
}
