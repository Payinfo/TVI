package com.oatec.tviplayer.data.playlist

object PlaylistValidator {
    fun validate(source: PlaylistSource): String? = when (source.type) {
        PlaylistType.M3U_URL, PlaylistType.M3U_FILE -> if (source.url.isNullOrBlank()) "M3U URL is required" else null
        PlaylistType.XTREAM -> when {
            source.server.isNullOrBlank() -> "Xtream server is required"
            source.username.isNullOrBlank() -> "Xtream username is required"
            source.password.isNullOrBlank() -> "Xtream password is required"
            else -> null
        }
    }
}
