package com.oatec.tviplayer.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oatec.tviplayer.data.db.PlaylistEntity

private enum class AddType { M3U_URL, M3U_FILE, XTREAM }

@Composable
fun PlaylistManagerScreen(onBack: () -> Unit, vm: PlaylistManagerViewModel = viewModel()) {
    val playlists by vm.playlists.collectAsState(initial = emptyList())
    val message by vm.message.collectAsState()
    val busy by vm.busy.collectAsState()
    var addType by remember { mutableStateOf<AddType?>(null) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) { selectedUri = uri; addType = AddType.M3U_FILE }
    }

    Column(Modifier.fillMaxSize().padding(48.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("PLAYLIST MANAGER", fontSize = 34.sp)
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = onBack) { Text("Back") }
        }
        Text("Add and manage your IPTV sources. Imported channels stay local to this device.", modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Button(onClick = { addType = AddType.M3U_URL }, enabled = !busy) { Text("M3U URL") }
            Button(onClick = { filePicker.launch(arrayOf("audio/x-mpegurl", "application/x-mpegURL", "text/plain", "*/*")) }, enabled = !busy) { Text("M3U File") }
            Button(onClick = { addType = AddType.XTREAM }, enabled = !busy) { Text("Xtream") }
        }

        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 18.dp))
        if (!message.isNullOrBlank()) {
            Card(Modifier.fillMaxWidth().padding(top = 12.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(message!!, Modifier.weight(1f)); TextButton(onClick = vm::clearMessage) { Text("OK") }
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        if (playlists.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No playlists yet. Add M3U or Xtream to start.", fontSize = 20.sp) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(playlists, key = { it.id }) { item -> PlaylistRow(item, onDelete = { vm.delete(item) }) }
            }
        }
    }

    when (addType) {
        AddType.M3U_URL -> M3uUrlDialog(busy, onDismiss = { addType = null }) { name, url -> addType = null; vm.importUrl(name, url) }
        AddType.XTREAM -> XtreamDialog(busy, onDismiss = { addType = null }) { name, server, user, pass -> addType = null; vm.addXtream(name, server, user, pass) }
        AddType.M3U_FILE -> {
            val uri = selectedUri
            if (uri != null) M3uFileNameDialog(busy, onDismiss = { addType = null; selectedUri = null }) { name -> addType = null; selectedUri = null; vm.importFile(name, uri) }
        }
        null -> Unit
    }
}


@Composable private fun PlaylistRow(item: PlaylistEntity, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.name, fontSize = 21.sp)
                Text(item.type + if (item.server != null) " • ${item.server}" else "", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = onDelete) { Text("Delete") }
        }
    }
}

@Composable private fun M3uUrlDialog(busy: Boolean, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var url by remember { mutableStateOf("") }
    FormDialog("Add M3U URL", busy, onDismiss, saveEnabled = url.isNotBlank()) {
        Field("Playlist name", name) { name = it }; Field("M3U URL", url) { url = it }
        SaveButton { onSave(name, url) }
    }
}

@Composable private fun XtreamDialog(busy: Boolean, onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var server by remember { mutableStateOf("") }; var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    FormDialog("Add Xtream", busy, onDismiss, saveEnabled = server.isNotBlank() && user.isNotBlank() && pass.isNotBlank()) {
        Field("Playlist name", name) { name = it }; Field("Server URL", server) { server = it }; Field("Username", user) { user = it }; Field("Password", pass) { pass = it }
        SaveButton { onSave(name, server, user, pass) }
    }
}

@Composable private fun M3uFileNameDialog(busy: Boolean, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    FormDialog("Import M3U file", busy, onDismiss, saveEnabled = true) { Field("Playlist name", name) { name = it }; SaveButton { onSave(name) } }
}

@Composable private fun FormDialog(title: String, busy: Boolean, onDismiss: () -> Unit, saveEnabled: Boolean, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { content() } }, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable private fun Field(label: String, value: String, onValueChange: (String) -> Unit = {}) {
    OutlinedTextField(value, onValueChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}

@Composable private fun ColumnScope.SaveButton(onClick: () -> Unit) { Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text("Save") } }
