package com.oatec.tviplayer.data.api

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object ApiFactory {
    // OATEC control plane is HTTPS. IPTV provider URLs are handled separately and may be HTTP/HTTPS.
    private const val BASE_URL = "https://oatec.space/"
    val api: OatecApi = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(OkHttpClient.Builder().build())
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
        .create(OatecApi::class.java)
}
