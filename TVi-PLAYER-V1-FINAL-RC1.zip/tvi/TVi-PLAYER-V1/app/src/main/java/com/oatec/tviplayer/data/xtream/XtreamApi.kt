package com.oatec.tviplayer.data.xtream

import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url

/** Xtream Codes-compatible API. The provider is called directly; OATEC is not in the media path. */
interface XtreamApi {
    @GET
    suspend fun serverInfo(@Url url: String, @Query("username") username: String, @Query("password") password: String): XtreamAuthResponse

    @GET
    suspend fun liveCategories(@Url url: String, @Query("username") username: String, @Query("password") password: String, @Query("action") action: String = "get_live_categories"): List<XtreamCategoryResponse>

    @GET
    suspend fun vodCategories(@Url url: String, @Query("username") username: String, @Query("password") password: String, @Query("action") action: String = "get_vod_categories"): List<XtreamVodCategoryResponse>

    @GET
    suspend fun vodStreams(@Url url: String, @Query("username") username: String, @Query("password") password: String, @Query("action") action: String = "get_vod_streams"): List<XtreamMovieResponse>

    @GET
    suspend fun seriesCategories(@Url url: String, @Query("username") username: String, @Query("password") password: String, @Query("action") action: String = "get_series_categories"): List<XtreamVodCategoryResponse>

    @GET
    suspend fun series(@Url url: String, @Query("username") username: String, @Query("password") password: String, @Query("action") action: String = "get_series"): List<XtreamSeriesResponse>

    @GET
    suspend fun seriesInfo(@Url url: String, @Query("username") username: String, @Query("password") password: String, @Query("series_id") seriesId: String, @Query("action") action: String = "get_series_info"): XtreamSeriesInfoResponse

    @GET
    suspend fun liveStreams(@Url url: String, @Query("username") username: String, @Query("password") password: String, @Query("action") action: String = "get_live_streams"): List<XtreamLiveStreamResponse>
}
