package com.oatec.tviplayer.data.repository

import android.content.Context
import com.oatec.tviplayer.data.db.ChannelEntity
import com.oatec.tviplayer.data.db.PlayerDatabase
import com.oatec.tviplayer.data.db.PlaylistEntity
import com.oatec.tviplayer.data.playlist.PlaylistSource
import com.oatec.tviplayer.data.playlist.PlaylistType
import com.oatec.tviplayer.data.xtream.XtreamLiveSync
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LiveChannelRepository(context: Context) {
    private val dao = PlayerDatabase.get(context).playlistDao()
    private val xtream = XtreamLiveSync()

    suspend fun playlists(): List<PlaylistEntity> = withContext(Dispatchers.IO) { dao.observeOnce() }
    suspend fun channelsForPlaylist(playlist: PlaylistEntity): List<ChannelEntity> = withContext(Dispatchers.IO) {
        if (playlist.type == PlaylistType.XTREAM.name) {
            val source = PlaylistSource(playlist.id, playlist.name, PlaylistType.XTREAM, server = playlist.server, username = playlist.username, password = playlist.password)
            val channels = xtream.load(source)
            dao.deleteChannels(playlist.id)
            dao.upsertChannels(channels)
            channels
        } else dao.channels(playlist.id)
    }

    suspend fun allChannels(): List<ChannelEntity> = withContext(Dispatchers.IO) {
        playlists().flatMap { p -> if (p.type == PlaylistType.XTREAM.name) channelsForPlaylist(p) else dao.channels(p.id) }
            .distinctBy { it.id }
            .sortedWith(compareBy<ChannelEntity> { it.number ?: Int.MAX_VALUE }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }
}

private suspend fun com.oatec.tviplayer.data.db.PlaylistDao.observeOnce(): List<PlaylistEntity> = kotlinx.coroutines.flow.first(observePlaylists())
