package com.oatec.tviplayer.data.xtream

import com.oatec.tviplayer.data.db.ChannelEntity
import com.oatec.tviplayer.data.playlist.PlaylistSource
import com.oatec.tviplayer.data.playlist.PlaylistType

class XtreamLiveSync(private val repository: XtreamRepository = XtreamRepository()) {
    suspend fun load(source: PlaylistSource): List<ChannelEntity> {
        require(source.type == PlaylistType.XTREAM)
        val categories = repository.categories(source).associateBy { it.categoryId }
        return repository.liveStreams(source).mapIndexed { index, stream ->
            val category = stream.categoryId?.let { categories[it]?.categoryName }
            ChannelEntity(
                id = "${source.id}:xtream:${stream.streamId}",
                providerId = source.id,
                name = stream.name,
                streamUrl = XtreamStreamUrl.live(source, stream.streamId, extensionFor(stream.streamType)),
                logoUrl = stream.streamIcon,
                groupName = category,
                tvgId = stream.epgChannelId,
                tvgName = stream.name,
                number = stream.num ?: index + 1
            )
        }
    }

    private fun extensionFor(streamType: String?): String = when (streamType?.lowercase()) {
        "m3u8", "hls" -> "m3u8"
        else -> "ts"
    }
}
