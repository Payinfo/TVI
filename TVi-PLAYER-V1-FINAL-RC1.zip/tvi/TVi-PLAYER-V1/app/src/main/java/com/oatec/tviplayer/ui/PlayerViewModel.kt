package com.oatec.tviplayer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oatec.tviplayer.data.model.*
import com.oatec.tviplayer.data.repository.OatecRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class AppMode { CHOOSE, PREMIUM, STANDARD }
data class PlayerUiState(
    val mode: AppMode = AppMode.CHOOSE,
    val loading: Boolean = false,
    val message: String? = null,
    val activated: Boolean = false,
    val subscription: Subscription? = null,
    val config: PlayerConfig? = null
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = OatecRepository(app)
    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state
    private var heartbeatJob: Job? = null

    init {
        viewModelScope.launch { restoreSession() }
    }

    fun choose(mode: AppMode) { _state.value = _state.value.copy(mode = mode, message = null) }

    private suspend fun restoreSession() {
        if (repo.token() == null) return
        val r = repo.me()
        if (r?.ok == true) {
            _state.value = _state.value.copy(activated = true, subscription = r.subscription, config = r.config, mode = AppMode.PREMIUM, message = "Premium activated")
            startHeartbeat()
        } else if (r != null && !r.ok) repo.clearSession()
    }

    fun activate(code: String) {
        if (code.isBlank()) { _state.value = _state.value.copy(message = "Enter your activation code"); return }
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, message = null)
            runCatching { repo.activate(code) }
                .onSuccess { r ->
                    _state.value = _state.value.copy(loading = false, activated = r.ok, subscription = r.subscription, config = r.config, message = r.error ?: if (r.ok) "Activated successfully" else "Activation failed")
                    if (r.ok) startHeartbeat()
                }
                .onFailure { e -> _state.value = _state.value.copy(loading = false, message = e.message ?: "Connection error") }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repo.logout()
            heartbeatJob?.cancel()
            _state.value = PlayerUiState(mode = AppMode.CHOOSE, message = "Logged out")
        }
    }

    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (true) {
                delay(5 * 60 * 1000L)
                val r = repo.heartbeat()
                if (r?.ok == false) {
                    repo.clearSession()
                    _state.value = _state.value.copy(activated = false, message = r.error ?: "Premium session expired")
                    break
                }
            }
        }
    }

    override fun onCleared() {
        heartbeatJob?.cancel()
        super.onCleared()
    }
}
