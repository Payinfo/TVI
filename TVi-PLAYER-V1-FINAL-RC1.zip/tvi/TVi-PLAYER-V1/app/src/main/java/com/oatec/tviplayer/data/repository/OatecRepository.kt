package com.oatec.tviplayer.data.repository

import android.content.Context
import android.provider.Settings
import com.oatec.tviplayer.BuildConfig
import com.oatec.tviplayer.data.api.ApiFactory
import com.oatec.tviplayer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class OatecRepository(private val context: Context) {
    private val api = ApiFactory.api
    private val prefs = context.getSharedPreferences("oatec_session", Context.MODE_PRIVATE)

    private fun deviceId(): String = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"
    private fun deviceName(): String = android.os.Build.MODEL?.takeIf { it.isNotBlank() } ?: "Android TV"
    private fun bearer(token: String) = "Bearer $token"

    suspend fun activate(code: String) = withContext(Dispatchers.IO) {
        val response = api.activate(ActivateRequest(code.trim().uppercase(), deviceId(), deviceName(), appVersion = BuildConfig.VERSION_NAME))
        if (response.ok && !response.token.isNullOrBlank()) saveToken(response.token)
        response
    }

    suspend fun me(): MeResponse? = withContext(Dispatchers.IO) {
        val token = token() ?: return@withContext null
        runCatching { api.me(bearer(token)) }.getOrNull()
    }

    suspend fun heartbeat(): BasicResponse? = withContext(Dispatchers.IO) {
        val token = token() ?: return@withContext null
        runCatching { api.heartbeat(bearer(token), HeartbeatRequest(deviceName(), BuildConfig.VERSION_NAME)) }.getOrNull()
    }

    suspend fun logout(): Boolean = withContext(Dispatchers.IO) {
        val token = token() ?: return@withContext true
        val ok = runCatching { api.logout(bearer(token)).ok }.getOrDefault(false)
        clearSession()
        ok
    }

    fun token(): String? = prefs.getString("token", null)
    private fun saveToken(token: String) { prefs.edit().putString("token", token).apply() }
    fun clearSession() { prefs.edit().remove("token").apply() }
}
