package com.oatec.tviplayer.ui.live

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oatec.tviplayer.data.db.ChannelEntity
import com.oatec.tviplayer.data.db.PlayerDatabase
import com.oatec.tviplayer.data.db.UserCategoryEntity
import com.oatec.tviplayer.data.repository.LiveChannelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class LiveTvState(
    val loading: Boolean = true,
    val channels: List<ChannelEntity> = emptyList(),
    val selectedIndex: Int = 0,
    val error: String? = null,
    val favoritesOnly: Boolean = false,
    val categories: List<UserCategoryEntity> = emptyList(),
    val history: List<ChannelEntity> = emptyList()
)

class LiveTvViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = LiveChannelRepository(app)
    private val dao = PlayerDatabase.get(app).playlistDao()
    private val _state = MutableStateFlow(LiveTvState())
    val state: StateFlow<LiveTvState> = _state.asStateFlow()

    init {
        viewModelScope.launch { dao.observeCategories().collect { _state.value = _state.value.copy(categories = it) } }
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching { repo.allChannels() }
                .onSuccess { list -> updateChannels(list) }
                .onFailure { e -> _state.value = _state.value.copy(loading = false, error = e.message ?: "Could not load channels") }
        }
    }

    private fun updateChannels(list: List<ChannelEntity>) {
        val visible = if (_state.value.favoritesOnly) list.filter { it.isFavorite } else list
        _state.value = _state.value.copy(loading = false, channels = visible, selectedIndex = 0, error = if (visible.isEmpty()) "No channels found. Add an M3U or Xtream playlist first." else null)
    }

    fun toggleFavorites() {
        viewModelScope.launch {
            val all = repo.allChannels()
            val next = !_state.value.favoritesOnly
            val visible = if (next) all.filter { it.isFavorite } else all
            _state.value = _state.value.copy(favoritesOnly = next, channels = visible, selectedIndex = 0)
        }
    }

    fun toggleFavorite() {
        val channel = _state.value.channels.getOrNull(_state.value.selectedIndex) ?: return
        viewModelScope.launch {
            dao.setFavorite(channel.id, !channel.isFavorite)
            refresh()
        }
    }

    fun createCategory(name: String) {
        val clean = name.trim(); if (clean.isEmpty()) return
        viewModelScope.launch { dao.upsertCategory(UserCategoryEntity(UUID.randomUUID().toString(), clean, _state.value.categories.size)) }
    }

    fun assignSelectedToCategory(categoryId: String?) {
        val channel = _state.value.channels.getOrNull(_state.value.selectedIndex) ?: return
        viewModelScope.launch { dao.assignCategory(channel.id, categoryId); refresh() }
    }

    fun renumberSelected(number: Int) {
        if (number < 1) return
        val channel = _state.value.channels.getOrNull(_state.value.selectedIndex) ?: return
        viewModelScope.launch { dao.setNumber(channel.id, number); refresh() }
    }

    fun recordHistory() {
        val channel = _state.value.channels.getOrNull(_state.value.selectedIndex) ?: return
        viewModelScope.launch { dao.addHistory(com.oatec.tviplayer.data.db.WatchHistoryEntity(channel.id)) }
    }

    fun loadHistory() {
        viewModelScope.launch { _state.value = _state.value.copy(history = dao.history()) }
    }

    fun select(index: Int) {
        val list = _state.value.channels
        if (list.isNotEmpty()) { _state.value = _state.value.copy(selectedIndex = index.coerceIn(0, list.lastIndex)); recordHistory() }
    }
    fun next() = select(_state.value.selectedIndex + 1)
    fun previous() = select(_state.value.selectedIndex - 1)
}
