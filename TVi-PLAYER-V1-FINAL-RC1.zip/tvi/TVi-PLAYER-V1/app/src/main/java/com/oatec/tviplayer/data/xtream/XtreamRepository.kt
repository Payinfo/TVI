package com.oatec.tviplayer.data.xtream

import com.oatec.tviplayer.data.playlist.PlaylistSource
import com.oatec.tviplayer.data.playlist.PlaylistType
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class XtreamRepository {
    private fun api() = Retrofit.Builder()
        .baseUrl("https://localhost/")
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
        .create(XtreamApi::class.java)

    private fun playerApiUrl(source: PlaylistSource): String {
        require(source.type == PlaylistType.XTREAM) { "Not an Xtream source" }
        return requireNotNull(source.server).trimEnd('/') + "/player_api.php"
    }

    suspend fun authenticate(source: PlaylistSource): XtreamAuthResponse = api().serverInfo(
        playerApiUrl(source), requireNotNull(source.username), requireNotNull(source.password)
    )

    suspend fun categories(source: PlaylistSource): List<XtreamCategoryResponse> = api().liveCategories(
        playerApiUrl(source), requireNotNull(source.username), requireNotNull(source.password)
    )

    suspend fun liveStreams(source: PlaylistSource): List<XtreamLiveStreamResponse> = api().liveStreams(
        playerApiUrl(source), requireNotNull(source.username), requireNotNull(source.password)
    )
}
