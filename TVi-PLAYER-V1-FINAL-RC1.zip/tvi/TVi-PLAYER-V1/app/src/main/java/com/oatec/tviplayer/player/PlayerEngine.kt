package com.oatec.tviplayer.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** TV-focused playback controller with source failover and bounded reconnects. */
class PlayerEngine(context: Context) {
    private val appContext = context.applicationContext
    val player: ExoPlayer = ExoPlayer.Builder(appContext).build().apply {
        playWhenReady = true
    }

    private var sources: List<String> = emptyList()
    private var sourceIndex = 0
    private var retryCount = 0
    private val maxRetriesPerSource = 2
    private var listener: ((String) -> Unit)? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                retryOrFailover(error)
            }
        })
    }

    fun setStatusListener(callback: (String) -> Unit) { listener = callback }

    fun play(primary: String, backup: String? = null) {
        sources = listOfNotNull(primary.trim().takeIf { it.isNotEmpty() }, backup?.trim()?.takeIf { it.isNotEmpty() }).distinct()
        sourceIndex = 0
        retryCount = 0
        prepareCurrent()
    }

    fun stop() { player.stop() }

    fun release() { player.release() }

    fun setMute(muted: Boolean) { player.volume = if (muted) 0f else 1f }

    fun setSpeed(speed: Float) { player.setPlaybackSpeed(speed.coerceIn(0.5f, 2f)) }

    private fun prepareCurrent() {
        val url = sources.getOrNull(sourceIndex) ?: return
        listener?.invoke(if (sourceIndex == 0) "Playing primary source" else "Switched to backup source")
        player.setMediaItem(MediaItem.Builder().setUri(Uri.parse(url)).build())
        player.prepare()
        player.playWhenReady = true
    }

    private fun retryOrFailover(error: PlaybackException) {
        if (retryCount < maxRetriesPerSource) {
            retryCount++
            listener?.invoke("Reconnecting… ($retryCount/$maxRetriesPerSource)")
            player.prepare()
            player.playWhenReady = true
            return
        }
        if (sourceIndex + 1 < sources.size) {
            sourceIndex++
            retryCount = 0
            prepareCurrent()
        } else {
            listener?.invoke("Playback failed: ${error.errorCodeName}")
        }
    }
}
