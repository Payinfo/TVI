package com.oatec.tviplayer.data.playlist

enum class PlaylistType { M3U_URL, M3U_FILE, XTREAM }

data class PlaylistSource(
    val id: String,
    val name: String,
    val type: PlaylistType,
    val url: String? = null,
    val server: String? = null,
    val username: String? = null,
    val password: String? = null,
    val enabled: Boolean = true
)

data class Channel(
    val id: String,
    val providerId: String,
    val name: String,
    val streamUrl: String,
    val logoUrl: String? = null,
    val groupName: String? = null,
    val tvgId: String? = null,
    val tvgName: String? = null,
    val country: String? = null,
    val language: String? = null,
    val number: Int? = null
)
