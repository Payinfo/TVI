package com.oatec.tviplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.saveable.rememberSaveable
import com.oatec.tviplayer.ui.AppMode
import com.oatec.tviplayer.ui.PlayerViewModel
import com.oatec.tviplayer.ui.PlaylistManagerScreen
import com.oatec.tviplayer.ui.live.LiveTvScreen
import com.oatec.tviplayer.ui.EpgScreen
import com.oatec.tviplayer.ui.ContentScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { TViPlayerApp() } }
}

@Composable
fun TViPlayerApp(vm: PlayerViewModel = viewModel()) {
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val settings = remember { com.oatec.tviplayer.ui.TvSettingsStore(context) }
    val state by vm.state.collectAsState()
    MaterialTheme(colorScheme = darkColorScheme(background = Color(8, 10, 14), surface = Color(18, 21, 28))) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (settingsOpen) {
                SettingsScreen(settings = settings, onBack = { settingsOpen = false })
                return@Surface
            }
            when (state.mode) {
                AppMode.CHOOSE -> ModeChooser(onPremium = { vm.choose(AppMode.PREMIUM) }, onStandard = { vm.choose(AppMode.STANDARD) }, onSettings = { settingsOpen = true })
                AppMode.PREMIUM -> PremiumScreen(state.loading, state.message, state.activated, state.subscription, state.config, vm::activate, vm::logout, { vm.choose(AppMode.CHOOSE) })
                AppMode.STANDARD -> StandardScreen(back = { vm.choose(AppMode.CHOOSE) })
            }
        }
    }
}

@Composable private fun ModeChooser(onPremium: () -> Unit, onStandard: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(64.dp), verticalArrangement = Arrangement.Center) {
        Text("TVi PLAYER", fontSize = 42.sp, fontWeight = FontWeight.Bold)
        Text("Easy for beginners. Powerful for advanced users.", color = Color.LightGray, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp, bottom = 36.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            ModeCard("OATEC PREMIUM", "Activation code only", onPremium)
            ModeCard("STANDARD PLAYER", "M3U / Xtream", onStandard)
            ModeCard("SETTINGS", "Profiles / PIN / Language", onSettings)
        }
    }
}

@Composable private fun ModeCard(title: String, subtitle: String, action: () -> Unit) {
    Button(onClick = action, modifier = Modifier.width(300.dp).height(150.dp), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(24.dp)) {
        Column(horizontalAlignment = Alignment.Start) { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Text(subtitle, fontSize = 16.sp) }
    }
}

@Composable private fun PremiumScreen(loading: Boolean, message: String?, activated: Boolean, subscription: com.oatec.tviplayer.data.model.Subscription?, config: com.oatec.tviplayer.data.model.PlayerConfig?, activate: (String) -> Unit, logout: () -> Unit, back: () -> Unit) {
    var code by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (!activated) focus.requestFocus() }
    Column(Modifier.fillMaxSize().padding(64.dp), verticalArrangement = Arrangement.Center) {
        Text("OATEC PREMIUM", fontSize = 38.sp, fontWeight = FontWeight.Bold)
        if (!activated) {
            Text("Enter your activation code. No server, username or password needed.", color = Color.LightGray, modifier = Modifier.padding(top = 8.dp, bottom = 28.dp))
            OutlinedTextField(value = code, onValueChange = { code = it.uppercase() }, modifier = Modifier.width(460.dp).focusRequester(focus), label = { Text("Activation code") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Button(onClick = { activate(code) }, enabled = !loading, modifier = Modifier.width(190.dp).height(54.dp)) { Text(if (loading) "Connecting…" else "Activate") }
                OutlinedButton(onClick = back, modifier = Modifier.height(54.dp)) { Text("Back") }
            }
        } else {
            Text("Connected to OATEC", color = Color(120, 220, 150), fontSize = 20.sp)
            Text("Subscription: ${subscription?.status ?: config?.status ?: "active"}", modifier = Modifier.padding(top = 12.dp))
            Text("Expires: ${subscription?.expiresAt ?: config?.expiresAt ?: "—"}", color = Color.LightGray)
            Text("Provider configuration received securely from OATEC.", color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Button(onClick = { logout() }, modifier = Modifier.height(54.dp)) { Text("Logout") }
                OutlinedButton(onClick = back, modifier = Modifier.height(54.dp)) { Text("Back") }
            }
        }
        if (!message.isNullOrBlank()) Text(message, color = if (activated) Color(120, 220, 150) else Color(255, 150, 150), modifier = Modifier.padding(top = 20.dp))
    }
}

@Composable
private fun StandardScreen(back: () -> Unit) {
    var manager by remember { mutableStateOf(false) }
    var live by remember { mutableStateOf(false) }
    var epg by remember { mutableStateOf(false) }
    var content by remember { mutableStateOf(false) }
    if (content) { ContentScreen(onBack = { content = false }); return }
    if (live) { LiveTvScreen(onBack = { live = false }); return }
    if (epg) { EpgScreen(onBack = { epg = false }); return }
    if (manager) {
        PlaylistManagerScreen(onBack = { manager = false })
        return
    }
    Column(Modifier.fillMaxSize().padding(64.dp), verticalArrangement = Arrangement.Center) {
        Text("STANDARD PLAYER", fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Text("Independent mode — M3U URL, M3U file or Xtream credentials.", color = Color.LightGray, modifier = Modifier.padding(vertical = 12.dp))
        Button(onClick = { live = true }, modifier = Modifier.width(320.dp).height(58.dp)) { Text("Live TV") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { content = true }, modifier = Modifier.width(320.dp).height(58.dp)) { Text("Movies & Series") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { epg = true }, modifier = Modifier.width(320.dp).height(58.dp)) { Text("EPG / TV Guide") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { manager = true }, modifier = Modifier.width(320.dp).height(58.dp)) { Text("Playlist Manager") }
        Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = back) { Text("Back") }
    }
}


@Composable
private fun SettingsScreen(settings: com.oatec.tviplayer.ui.TvSettingsStore, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var language by remember { mutableStateOf(settings.language) }
    var profile by remember { mutableStateOf(settings.profileName) }
    var pinEnabled by remember { mutableStateOf(settings.pinEnabled) }
    var pin by remember { mutableStateOf(settings.pin) }
    var autoplay by remember { mutableStateOf(settings.autoplay) }
    var epg by remember { mutableStateOf(settings.epgEnabled) }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 70.dp, vertical = 42.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("SETTINGS", fontSize = 38.sp, fontWeight = FontWeight.Bold); Text("TV-first controls", color = Color.LightGray) }
            OutlinedButton(onClick = onBack) { Text("Back") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(30.dp)) {
            Column(Modifier.width(430.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Profile", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(profile, { profile = it }, label = { Text("Profile name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { settings.profileName = profile; Toast.makeText(context, "Profile saved", Toast.LENGTH_SHORT).show() }, modifier = Modifier.height(52.dp)) { Text("Save profile") }
            }
            Column(Modifier.width(430.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Language", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("English", "Français", "Deutsch", "العربية").forEach { lang ->
                        FilterChip(selected = language == lang, onClick = { language = lang; settings.language = lang }, label = { Text(lang) })
                    }
                }
            }
        }
        HorizontalDivider()
        Text("Parental control", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = pinEnabled, onCheckedChange = { pinEnabled = it; settings.pinEnabled = it })
            Text("Require PIN for protected profiles/content", Modifier.padding(start = 12.dp))
        }
        if (pinEnabled) {
            OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6) }, label = { Text("PIN (4–6 digits)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.width(320.dp))
            Button(onClick = { settings.pin = pin }, enabled = pin.length >= 4) { Text("Save PIN") }
        }
        HorizontalDivider()
        Text("Playback", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(autoplay, { autoplay = it; settings.autoplay = it }); Text("Autoplay last selected channel", Modifier.padding(start = 12.dp)) }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(epg, { epg = it; settings.epgEnabled = it }); Text("Enable EPG updates", Modifier.padding(start = 12.dp)) }
        Text("Landscape / remote-first mode is always enabled for TV.", color = Color.LightGray)
    }
}
