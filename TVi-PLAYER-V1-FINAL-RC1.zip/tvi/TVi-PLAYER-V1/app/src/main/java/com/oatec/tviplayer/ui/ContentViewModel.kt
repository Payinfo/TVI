package com.oatec.tviplayer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oatec.tviplayer.data.content.*
import com.oatec.tviplayer.data.db.PlayerDatabase
import com.oatec.tviplayer.data.playlist.PlaylistSource
import com.oatec.tviplayer.data.playlist.PlaylistType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ContentViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = PlayerDatabase.get(app).playlistDao()
    private val repo = ContentRepository()
    private val _movies = MutableStateFlow<List<VodMovie>>(emptyList())
    val movies: StateFlow<List<VodMovie>> = _movies.asStateFlow()
    private val _series = MutableStateFlow<List<VodSeries>>(emptyList())
    val series: StateFlow<List<VodSeries>> = _series.asStateFlow()
    private val _episodes = MutableStateFlow<List<VodEpisode>>(emptyList())
    val episodes: StateFlow<List<VodEpisode>> = _episodes.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun loadMovies() = viewModelScope.launch { withXtream { _movies.value = repo.movies(it) } }
    fun loadSeries() = viewModelScope.launch { withXtream { _series.value = repo.series(it) } }
    fun loadEpisodes(seriesId: String) = viewModelScope.launch { withXtream { _episodes.value = repo.seriesEpisodes(it, seriesId) } }
    fun clearMessage() { _message.value = null }

    private suspend fun withXtream(block: suspend (PlaylistSource) -> Unit) {
        _loading.value = true; _message.value = null
        try {
            val p = dao.observePlaylistsSnapshot().firstOrNull { it.enabled && it.type == PlaylistType.XTREAM.name }
                ?: error("Add an Xtream playlist first")
            block(PlaylistSource(p.id,p.name,PlaylistType.XTREAM,p.url,p.server,p.username,p.password,p.enabled))
        } catch (e: Exception) { _message.value = e.message ?: "Unable to load content" }
        finally { _loading.value = false }
    }
}
