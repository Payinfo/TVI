package com.oatec.tviplayer.data.content
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale
object XmltvParser {
 private fun time(v:String)=runCatching{SimpleDateFormat("yyyyMMddHHmmss Z",Locale.US).parse(v.trim())?.time?:0L}.getOrElse{runCatching{SimpleDateFormat("yyyyMMddHHmmss",Locale.US).parse(v.trim())?.time?:0L}.getOrDefault(0L)}
 fun parse(xml:String):List<EpgProgramme>{val out=mutableListOf<EpgProgramme>();val p=Xml.newPullParser();p.setInput(StringReader(xml));var e=p.eventType;var ch="";var st=0L;var en=0L;var title="";var desc:String?=null;var tag="";while(e!=XmlPullParser.END_DOCUMENT){when(e){XmlPullParser.START_TAG->{tag=p.name;if(tag=="programme"){ch=p.getAttributeValue(null,"channel")? :"";st=time(p.getAttributeValue(null,"start")?:"");en=time(p.getAttributeValue(null,"stop")?:"");title="";desc=null}};XmlPullParser.TEXT->{if(tag=="title")title=p.text;if(tag=="desc")desc=p.text};XmlPullParser.END_TAG->{if(p.name=="programme"&&ch.isNotBlank()&&title.isNotBlank())out+=EpgProgramme(ch,st,en,title.trim(),desc?.trim());tag=""}};e=p.next()};return out}
}
