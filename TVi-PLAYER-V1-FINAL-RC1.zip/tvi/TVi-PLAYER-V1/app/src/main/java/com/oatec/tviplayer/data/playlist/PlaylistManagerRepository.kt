package com.oatec.tviplayer.data.playlist

import android.content.Context
import android.net.Uri
import com.oatec.tviplayer.data.db.ChannelEntity
import com.oatec.tviplayer.data.db.PlaylistDao
import com.oatec.tviplayer.data.db.PlaylistEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class PlaylistManagerRepository(private val context: Context, private val dao: PlaylistDao) {
    private val engine = PlaylistEngine()

    suspend fun importM3uUrl(name: String, url: String): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val id = UUID.randomUUID().toString()
            val source = PlaylistSource(id, name.trim().ifBlank { "M3U Playlist" }, PlaylistType.M3U_URL, url = url.trim())
            val channels = engine.loadM3u(source)
            dao.upsertPlaylist(source.toEntity())
            dao.deleteChannels(id)
            dao.upsertChannels(channels.mapIndexed { index, c -> c.toEntity(number = c.number ?: index + 1) })
            channels.size
        }
    }

    suspend fun importM3uFile(name: String, uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("Could not open the selected file")
            val id = UUID.randomUUID().toString()
            val source = PlaylistSource(id, name.trim().ifBlank { "M3U File" }, PlaylistType.M3U_FILE, url = "content://$uri")
            val channels = M3uParser.parse(text, id)
            dao.upsertPlaylist(source.toEntity())
            dao.deleteChannels(id)
            dao.upsertChannels(channels.mapIndexed { index, c -> c.toEntity(number = c.number ?: index + 1) })
            channels.size
        }
    }

    suspend fun addXtream(name: String, server: String, username: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(server.isNotBlank() && username.isNotBlank() && password.isNotBlank()) { "Server, username and password are required" }
            val id = UUID.randomUUID().toString()
            dao.upsertPlaylist(PlaylistEntity(id, name.trim().ifBlank { "Xtream Playlist" }, PlaylistType.XTREAM.name, server = server.trimEnd('/'), username = username.trim(), password = password))
        }
    }

    suspend fun delete(item: PlaylistEntity) = withContext(Dispatchers.IO) {
        dao.deleteChannels(item.id)
        dao.deletePlaylist(item)
    }

    private fun PlaylistSource.toEntity() = PlaylistEntity(id, name, type.name, url, server, username, password, enabled = true)
    private fun Channel.toEntity(number: Int?) = ChannelEntity(id, providerId, name, streamUrl, logoUrl, groupName, tvgId, tvgName, country, language, number)
}
