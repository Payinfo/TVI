package com.oatec.tviplayer.ui

import android.content.Context

class TvSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("tvi_settings", Context.MODE_PRIVATE)
    var language: String
        get() = prefs.getString("language", "English") ?: "English"
        set(v) { prefs.edit().putString("language", v).apply() }
    var profileName: String
        get() = prefs.getString("profile_name", "Main Profile") ?: "Main Profile"
        set(v) { prefs.edit().putString("profile_name", v).apply() }
    var pinEnabled: Boolean
        get() = prefs.getBoolean("pin_enabled", false)
        set(v) { prefs.edit().putBoolean("pin_enabled", v).apply() }
    var pin: String
        get() = prefs.getString("pin", "") ?: ""
        set(v) { prefs.edit().putString("pin", v).apply() }
    var autoplay: Boolean
        get() = prefs.getBoolean("autoplay", true)
        set(v) { prefs.edit().putBoolean("autoplay", v).apply() }
    var epgEnabled: Boolean
        get() = prefs.getBoolean("epg", true)
        set(v) { prefs.edit().putBoolean("epg", v).apply() }
}
