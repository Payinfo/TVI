package com.oatec.tviplayer.data.playlist

data class XtreamCategory(val categoryId: String, val categoryName: String, val parentId: String? = null)

data class XtreamStream(
    val streamId: Int,
    val name: String,
    val streamIcon: String? = null,
    val categoryId: String? = null,
    val tvgId: String? = null,
    val tvgName: String? = null
)
