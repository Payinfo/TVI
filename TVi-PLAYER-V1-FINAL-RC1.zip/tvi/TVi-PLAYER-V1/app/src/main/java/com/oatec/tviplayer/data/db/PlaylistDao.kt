package com.oatec.tviplayer.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE") fun observePlaylists(): Flow<List<PlaylistEntity>>
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE") suspend fun observePlaylistsSnapshot(): List<PlaylistEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertPlaylist(item: PlaylistEntity)
    @Delete suspend fun deletePlaylist(item: PlaylistEntity)
    @Query("DELETE FROM channels WHERE providerId = :providerId") suspend fun deleteChannels(providerId: String)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertChannels(items: List<ChannelEntity>)
    @Query("SELECT * FROM channels WHERE providerId = :providerId ORDER BY COALESCE(number, 2147483647), name COLLATE NOCASE") suspend fun channels(providerId: String): List<ChannelEntity>
    @Query("SELECT * FROM channels ORDER BY COALESCE(number, 2147483647), name COLLATE NOCASE") suspend fun allChannels(): List<ChannelEntity>
    @Query("SELECT * FROM channels WHERE isFavorite = 1 ORDER BY COALESCE(number, 2147483647), name COLLATE NOCASE") suspend fun favorites(): List<ChannelEntity>
    @Query("UPDATE channels SET isFavorite = :favorite, updatedAt = :updatedAt WHERE id = :channelId") suspend fun setFavorite(channelId: String, favorite: Boolean, updatedAt: Long = System.currentTimeMillis())
    @Query("UPDATE channels SET userCategoryId = :categoryId, updatedAt = :updatedAt WHERE id = :channelId") suspend fun assignCategory(channelId: String, categoryId: String?, updatedAt: Long = System.currentTimeMillis())
    @Query("UPDATE channels SET number = :number, updatedAt = :updatedAt WHERE id = :channelId") suspend fun setNumber(channelId: String, number: Int, updatedAt: Long = System.currentTimeMillis())
    @Query("SELECT * FROM user_categories ORDER BY sortOrder, name COLLATE NOCASE") fun observeCategories(): Flow<List<UserCategoryEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertCategory(category: UserCategoryEntity)
    @Query("DELETE FROM user_categories WHERE id = :id") suspend fun deleteCategory(id: String)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addHistory(item: WatchHistoryEntity)
    @Query("SELECT c.* FROM watch_history h INNER JOIN channels c ON c.id = h.channelId ORDER BY h.watchedAt DESC LIMIT :limit") suspend fun history(limit: Int = 50): List<ChannelEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertEpg(items: List<EpgEntity>)
    @Query("DELETE FROM epg_programmes") suspend fun clearEpg()
    @Query("SELECT * FROM epg_programmes WHERE channelId = :channelId AND end >= :now ORDER BY start LIMIT :limit") suspend fun epgForChannel(channelId: String, now: Long, limit: Int = 12): List<EpgEntity>
    @Query("SELECT * FROM epg_programmes WHERE end >= :now ORDER BY start LIMIT :limit") suspend fun currentEpg(now: Long, limit: Int = 100): List<EpgEntity>
}
