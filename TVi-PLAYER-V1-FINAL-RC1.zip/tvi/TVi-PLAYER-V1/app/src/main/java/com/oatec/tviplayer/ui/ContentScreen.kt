package com.oatec.tviplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.oatec.tviplayer.data.content.*

@Composable
fun ContentScreen(vm: ContentViewModel = viewModel(), onBack: () -> Unit) {
    var tab by remember { mutableStateOf("Movies") }
    var selectedMovie by remember { mutableStateOf<VodMovie?>(null) }
    var selectedSeries by remember { mutableStateOf<VodSeries?>(null) }
    val movies by vm.movies.collectAsState(); val series by vm.series.collectAsState(); val episodes by vm.episodes.collectAsState()
    val loading by vm.loading.collectAsState(); val message by vm.message.collectAsState()
    LaunchedEffect(tab) { if (tab == "Movies" && movies.isEmpty()) vm.loadMovies(); if (tab == "Series" && series.isEmpty()) vm.loadSeries() }
    if (selectedMovie != null) { VodDetailScreen(selectedMovie!!, onBack={selectedMovie=null}); return }
    if (selectedSeries != null) {
        SeriesDetailScreen(selectedSeries!!, episodes, loading, onLoad={vm.loadEpisodes(selectedSeries!!.id)}, onBack={selectedSeries=null})
        return
    }
    Column(Modifier.fillMaxSize().padding(horizontal=56.dp, vertical=34.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Column { Text("CONTENT", fontSize=36.sp, fontWeight=FontWeight.Bold); Text("Movies & Series", color=Color.LightGray) }
            OutlinedButton(onClick=onBack) { Text("Back") }
        }
        Row(Modifier.padding(top=20.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            FilterChip(selected=tab=="Movies", onClick={tab="Movies"}, label={Text("Movies")})
            FilterChip(selected=tab=="Series", onClick={tab="Series"}, label={Text("Series")})
            if (loading) { CircularProgressIndicator(Modifier.size(24.dp).padding(start=8.dp), strokeWidth=2.dp) }
        }
        message?.let { Text(it, color=Color(255,150,150), modifier=Modifier.padding(top=12.dp)) }
        Spacer(Modifier.height(22.dp))
        if (tab=="Movies") ContentRail(movies, {it.name}, {it.posterUrl}, {selectedMovie=it})
        else ContentRail(series, {it.name}, {it.posterUrl}, {selectedSeries=it})
    }
}

@Composable private fun <T> ContentRail(items: List<T>, title:(T)->String, image:(T)->String?, click:(T)->Unit) {
    if (items.isEmpty()) { Text("No content available. Add an Xtream playlist in Playlist Manager.", color=Color.LightGray); return }
    LazyRow(horizontalArrangement=Arrangement.spacedBy(18.dp)) {
        items(items) { item ->
            var focused by remember { mutableStateOf(false) }
            Card(onClick={click(item)}, modifier=Modifier.width(180.dp).height(290.dp).onFocusChanged{focused=it.isFocused}.focusable(), shape=RoundedCornerShape(12.dp), colors=CardDefaults.cardColors(containerColor=if(focused) Color(45,50,62) else Color(22,25,32))) {
                Column {
                    AsyncImage(model=image(item), contentDescription=null, modifier=Modifier.fillMaxWidth().height(235.dp).clip(RoundedCornerShape(topStart=12.dp,topEnd=12.dp)).background(Color(12,14,18)), contentScale=ContentScale.Crop)
                    Text(title(item), modifier=Modifier.padding(12.dp), maxLines=2, fontWeight=FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable private fun VodDetailScreen(movie: VodMovie, onBack:()->Unit) {
    Column(Modifier.fillMaxSize().padding(56.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text(movie.name, fontSize=34.sp, fontWeight=FontWeight.Bold); OutlinedButton(onClick=onBack){Text("Back")} }
        Row(Modifier.padding(top=26.dp), horizontalArrangement=Arrangement.spacedBy(30.dp)) {
            AsyncImage(movie.posterUrl, null, Modifier.width(250.dp).height(350.dp).clip(RoundedCornerShape(14.dp)), contentScale=ContentScale.Crop)
            Column(Modifier.widthIn(max=720.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                movie.rating?.let { Text("★ ${"%.1f".format(it)}") }; movie.duration?.let { Text("Duration: ${it/60} min", color=Color.LightGray) }
                Text(movie.plot ?: "No description available.", color=Color.LightGray, fontSize=18.sp)
                Button(onClick={}, modifier=Modifier.width(190.dp).height(56.dp)) { Text("Play") }
            }
        }
    }
}

@Composable private fun SeriesDetailScreen(series: VodSeries, episodes: List<VodEpisode>, loading:Boolean, onLoad:()->Unit, onBack:()->Unit) {
    Column(Modifier.fillMaxSize().padding(56.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text(series.name, fontSize=34.sp, fontWeight=FontWeight.Bold); OutlinedButton(onClick=onBack){Text("Back")} }
        Row(Modifier.padding(top=22.dp), horizontalArrangement=Arrangement.spacedBy(30.dp)) {
            AsyncImage(series.posterUrl, null, Modifier.width(220.dp).height(310.dp).clip(RoundedCornerShape(14.dp)), contentScale=ContentScale.Crop)
            Column(Modifier.weight(1f)) {
                Text(series.plot ?: "No description available.", color=Color.LightGray, fontSize=18.sp)
                Spacer(Modifier.height(16.dp)); Button(onClick=onLoad, enabled=!loading){Text(if(loading)"Loading…" else "Load Episodes")}
                Spacer(Modifier.height(14.dp));
                LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp)) { items(episodes) { e -> Card(onClick={}, modifier=Modifier.width(240.dp).height(130.dp).focusable()){Column(Modifier.padding(12.dp)){Text("S${e.season} · E${e.episode}", fontWeight=FontWeight.Bold);Text(e.name,maxLines=2);Text(e.duration?.let{"${it/60} min"}.orEmpty(),color=Color.LightGray)}} } }
            }
        }
    }
}
