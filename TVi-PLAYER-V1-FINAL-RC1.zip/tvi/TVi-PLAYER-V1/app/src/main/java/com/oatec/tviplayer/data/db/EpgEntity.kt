package com.oatec.tviplayer.data.db

import androidx.room.Entity

@Entity(tableName = "epg_programmes", primaryKeys = ["channelId", "start"])
data class EpgEntity(
    val channelId: String,
    val start: Long,
    val end: Long,
    val title: String,
    val description: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
