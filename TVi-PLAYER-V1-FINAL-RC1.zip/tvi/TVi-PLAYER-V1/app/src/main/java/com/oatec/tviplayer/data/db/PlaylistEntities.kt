package com.oatec.tviplayer.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val url: String? = null,
    val server: String? = null,
    val username: String? = null,
    val password: String? = null,
    val enabled: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "channels", primaryKeys = ["id"])
data class ChannelEntity(
    val id: String,
    val providerId: String,
    val name: String,
    val streamUrl: String,
    val backupStreamUrl: String? = null,
    val logoUrl: String? = null,
    val groupName: String? = null,
    val tvgId: String? = null,
    val tvgName: String? = null,
    val country: String? = null,
    val language: String? = null,
    val number: Int? = null,
    val isFavorite: Boolean = false,
    val userCategoryId: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)


@Entity(tableName = "user_categories")
data class UserCategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val sortOrder: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val channelId: String,
    val watchedAt: Long = System.currentTimeMillis(),
    val position: Int = 0
)
