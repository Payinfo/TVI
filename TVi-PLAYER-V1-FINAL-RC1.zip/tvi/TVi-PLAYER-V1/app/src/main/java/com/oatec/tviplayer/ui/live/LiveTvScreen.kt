package com.oatec.tviplayer.ui.live

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import com.oatec.tviplayer.data.db.ChannelEntity
import com.oatec.tviplayer.player.PlayerEngine

@Composable
fun LiveTvScreen(onBack: () -> Unit, vm: LiveTvViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val focus = remember { FocusRequester() }
    val engine = remember { PlayerEngine(context) }
    var playbackStatus by remember { mutableStateOf("Ready") }
    var muted by remember { mutableStateOf(false) }

    DisposableEffect(engine) {
        engine.setStatusListener { playbackStatus = it }
        onDispose { engine.release() }
    }
    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(state.selectedIndex, state.channels) {
        val channel = state.channels.getOrNull(state.selectedIndex) ?: return@LaunchedEffect
        engine.play(channel.streamUrl, channel.backupStreamUrl)
        vm.recordHistory()
    }

    Row(
        Modifier.fillMaxSize().background(Color(7, 9, 13)).focusRequester(focus).focusable().onKeyEvent {
            if (it.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) return@onKeyEvent false
            when (it.nativeKeyEvent.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { vm.previous(); true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { vm.next(); true }
                KeyEvent.KEYCODE_BACK -> { onBack(); true }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { if (engine.player.isPlaying) engine.player.pause() else engine.player.play(); true }
                KeyEvent.KEYCODE_VOLUME_MUTE -> { muted = !muted; engine.setMute(muted); true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> false
                else -> false
            }
        }
    ) {
        Box(Modifier.weight(1.45f).fillMaxHeight()) {
            AndroidView(factory = { ctx ->
                PlayerView(ctx).apply {
                    player = engine.player
                    useController = true
                    controllerShowTimeoutMs = 3500
                    controllerAutoShow = true
                }
            }, modifier = Modifier.fillMaxSize())
            Text(playbackStatus, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
        }
        Column(Modifier.weight(0.55f).fillMaxHeight().padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("LIVE TV", color = Color.White, fontSize = 24.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = vm::toggleFavorites) { Text(if (state.favoritesOnly) "All" else "★") }
                    TextButton(onClick = vm::toggleFavorite) { Text("Favorite") }
                    TextButton(onClick = vm::refresh) { Text("Refresh") }
                }
            }
            if (state.error != null) Text(state.error!!, color = Color(255, 170, 170), modifier = Modifier.padding(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxSize()) {
                itemsIndexed(state.channels) { index, channel ->
                    ChannelRow(channel, index == state.selectedIndex) { vm.select(index) }
                }
            }
        }
    }
}

@Composable private fun ChannelRow(channel: ChannelEntity, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) Color(40, 55, 75) else Color(18, 22, 30), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text((channel.number ?: 0).toString().padStart(3, '0'), color = Color.LightGray, fontSize = 14.sp, modifier = Modifier.width(42.dp))
            Column {
                Text(channel.name, color = Color.White, fontSize = 16.sp, maxLines = 1)
                channel.groupName?.let { Text(it, color = Color.Gray, fontSize = 12.sp) }
            }
        }
    }
}
