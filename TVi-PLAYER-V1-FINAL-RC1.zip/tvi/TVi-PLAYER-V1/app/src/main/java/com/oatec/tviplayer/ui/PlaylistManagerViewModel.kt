package com.oatec.tviplayer.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oatec.tviplayer.data.db.PlayerDatabase
import com.oatec.tviplayer.data.db.PlaylistEntity
import com.oatec.tviplayer.data.playlist.PlaylistManagerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PlaylistManagerViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = PlayerDatabase.get(app).playlistDao()
    private val repo = PlaylistManagerRepository(app, dao)
    val playlists = dao.observePlaylists()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun importUrl(name: String, url: String) = launch { repo.importM3uUrl(name, url) }
    fun importFile(name: String, uri: Uri) = launch { repo.importM3uFile(name, uri) }
    fun addXtream(name: String, server: String, user: String, pass: String) = launch { repo.addXtream(name, server, user, pass) }
    fun delete(item: PlaylistEntity) = launch { repo.delete(item) }
    fun clearMessage() { _message.value = null }

    private fun launch(action: suspend () -> Result<*>) {
        viewModelScope.launch {
            _busy.value = true
            action().onSuccess { value -> _message.value = if (value is Int) "Imported $value channels" else "Playlist saved" }
                .onFailure { _message.value = it.message ?: "Operation failed" }
            _busy.value = false
        }
    }
}
