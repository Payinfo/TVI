package com.oatec.tviplayer.data.content

data class VodMovie(val id:String,val name:String,val streamUrl:String,val posterUrl:String?,val backdropUrl:String?,val categoryId:String?,val plot:String?,val duration:Int?,val rating:Double?)
data class VodSeries(val id:String,val name:String,val posterUrl:String?,val backdropUrl:String?,val categoryId:String?,val plot:String?,val rating:Double?)
data class VodEpisode(val id:String,val season:Int,val episode:Int,val name:String,val streamUrl:String,val imageUrl:String?,val plot:String?,val duration:Int?)
data class EpgProgramme(val channelId:String,val start:Long,val end:Long,val title:String,val description:String?)
