package com.oatec.tviplayer.data.model

import com.squareup.moshi.Json

data class ActivateRequest(
    val code: String,
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "device_name") val deviceName: String,
    val platform: String = "android",
    @Json(name = "app_version") val appVersion: String = "1.0.0"
)

data class HeartbeatRequest(
    @Json(name = "device_name") val deviceName: String,
    @Json(name = "app_version") val appVersion: String
)

data class BasicResponse(val ok: Boolean, val error: String? = null)

data class ActivationResponse(
    val ok: Boolean,
    val token: String? = null,
    val error: String? = null,
    val subscription: Subscription? = null,
    val config: PlayerConfig? = null
)

data class Subscription(val status: String, @Json(name = "expires_at") val expiresAt: String?)
data class PlayerConfig(
    @Json(name = "account_id") val accountId: Long,
    val status: String,
    @Json(name = "expires_at") val expiresAt: String?,
    @Json(name = "max_connections") val maxConnections: Int = 1,
    val primary: ProviderConfig,
    val backup: ProviderConfig? = null,
    val failover: FailoverConfig? = null
)
data class ProviderConfig(
    val type: String,
    val url: String? = null,
    val server: String? = null,
    val username: String? = null,
    val password: String? = null,
    @Json(name = "portal_url") val portalUrl: String? = null,
    @Json(name = "mac_address") val macAddress: String? = null
)
data class FailoverConfig(val enabled: Boolean = false, @Json(name = "buffering_threshold_sec") val thresholdSec: Int = 7)
data class MeResponse(val ok: Boolean, val subscription: Subscription?, val config: PlayerConfig?, val error: String? = null)
