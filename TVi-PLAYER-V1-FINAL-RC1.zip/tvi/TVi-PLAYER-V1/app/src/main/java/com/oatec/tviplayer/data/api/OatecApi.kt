package com.oatec.tviplayer.data.api

import com.oatec.tviplayer.data.model.*
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface OatecApi {
    @POST("api/player/activate-by-code")
    suspend fun activate(@Body request: ActivateRequest): ActivationResponse

    @GET("api/player/me")
    suspend fun me(@Header("Authorization") bearer: String): MeResponse

    @POST("api/player/heartbeat")
    suspend fun heartbeat(@Header("Authorization") bearer: String, @Body request: HeartbeatRequest): BasicResponse

    @POST("api/player/logout")
    suspend fun logout(@Header("Authorization") bearer: String): BasicResponse
}
