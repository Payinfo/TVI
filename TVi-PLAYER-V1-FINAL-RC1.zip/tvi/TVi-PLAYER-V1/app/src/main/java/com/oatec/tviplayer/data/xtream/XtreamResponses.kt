package com.oatec.tviplayer.data.xtream

import com.squareup.moshi.Json

data class XtreamAuthResponse(
    @Json(name = "user_info") val userInfo: XtreamUserInfo? = null,
    @Json(name = "server_info") val serverInfo: XtreamServerInfo? = null
)

data class XtreamUserInfo(
    val username: String? = null,
    val status: String? = null,
    @Json(name = "exp_date") val expiration: String? = null,
    @Json(name = "is_trial") val isTrial: String? = null,
    @Json(name = "active_cons") val activeConnections: String? = null,
    @Json(name = "max_connections") val maxConnections: String? = null
)

data class XtreamServerInfo(
    val url: String? = null,
    val port: String? = null,
    @Json(name = "https_port") val httpsPort: String? = null,
    val protocol: String? = null,
    val timezone: String? = null
)

data class XtreamCategoryResponse(
    @Json(name = "category_id") val categoryId: String,
    @Json(name = "category_name") val categoryName: String,
    @Json(name = "parent_id") val parentId: String? = null
)

data class XtreamLiveStreamResponse(
    @Json(name = "num") val num: Int? = null,
    @Json(name = "name") val name: String,
    @Json(name = "stream_type") val streamType: String? = null,
    @Json(name = "stream_id") val streamId: Int,
    @Json(name = "stream_icon") val streamIcon: String? = null,
    @Json(name = "epg_channel_id") val epgChannelId: String? = null,
    @Json(name = "category_id") val categoryId: String? = null,
    @Json(name = "tv_archive") val tvArchive: Int? = null,
    @Json(name = "tv_archive_duration") val tvArchiveDuration: Int? = null
)
