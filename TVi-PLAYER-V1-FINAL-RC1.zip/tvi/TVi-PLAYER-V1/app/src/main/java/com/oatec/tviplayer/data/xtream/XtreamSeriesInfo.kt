package com.oatec.tviplayer.data.xtream

import com.squareup.moshi.Json

data class XtreamSeriesInfoResponse(
    @Json(name="info") val info: XtreamSeriesInfoMeta? = null,
    @Json(name="episodes") val episodes: Map<String, List<XtreamEpisodeResponse>>? = null
)

data class XtreamSeriesInfoMeta(
    @Json(name="name") val name: String? = null,
    @Json(name="cover") val cover: String? = null,
    @Json(name="plot") val plot: String? = null,
    @Json(name="rating") val rating: String? = null,
    @Json(name="backdrop_path") val backdropPath: List<String>? = null
)

data class XtreamEpisodeResponse(
    @Json(name="id") val id: String? = null,
    @Json(name="episode_num") val episodeNum: Int? = null,
    @Json(name="title") val title: String? = null,
    @Json(name="container_extension") val extension: String? = null,
    @Json(name="info") val info: XtreamEpisodeInfo? = null
)

data class XtreamEpisodeInfo(
    @Json(name="movie_image") val image: String? = null,
    @Json(name="plot") val plot: String? = null,
    @Json(name="duration_secs") val durationSecs: Int? = null
)
