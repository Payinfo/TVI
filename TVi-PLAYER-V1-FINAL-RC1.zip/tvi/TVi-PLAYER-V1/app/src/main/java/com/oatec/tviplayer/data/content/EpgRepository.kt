package com.oatec.tviplayer.data.content

import android.content.Context
import com.oatec.tviplayer.data.db.EpgEntity
import com.oatec.tviplayer.data.db.PlayerDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class EpgRepository(context: Context) {
    private val dao = PlayerDatabase.get(context).playlistDao()
    private val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    suspend fun importXmltv(url: String): Int = withContext(Dispatchers.IO) {
        require(url.startsWith("http://") || url.startsWith("https://")) { "EPG URL must use HTTP or HTTPS" }
        val request = Request.Builder().url(url).header("Accept", "application/xml,text/xml,*/*").build()
        val body = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("EPG download failed: HTTP ${response.code}")
            response.body?.string() ?: error("EPG response is empty")
        }
        val programmes = XmltvParser.parse(body)
        val rows = programmes.map { EpgEntity(it.channelId, it.start, it.end, it.title, it.description) }
        dao.clearEpg()
        if (rows.isNotEmpty()) dao.upsertEpg(rows)
        rows.size
    }

    suspend fun programmes(channelId: String, now: Long = System.currentTimeMillis()) = dao.epgForChannel(channelId, now)
    suspend fun current(now: Long = System.currentTimeMillis()) = dao.currentEpg(now)
}
