package com.oatec.tviplayer.data.playlist

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class PlaylistEngine(private val httpTimeoutMs: Int = 20_000) {
    suspend fun loadM3u(source: PlaylistSource): List<Channel> = withContext(Dispatchers.IO) {
        require(source.type == PlaylistType.M3U_URL || source.type == PlaylistType.M3U_FILE)
        val url = source.url ?: error("M3U URL is missing")
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = httpTimeoutMs
            readTimeout = httpTimeoutMs
            instanceFollowRedirects = true
            requestProperty("User-Agent", "TVi-PLAYER/1.0")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("Playlist request failed: HTTP ${connection.responseCode}")
            M3uParser.parse(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }, source.id)
        } finally { connection.disconnect() }
    }

    fun xtreamStreamUrl(source: PlaylistSource, streamId: Int, kind: String = "live", extension: String = "ts"): String {
        val server = (source.server ?: error("Xtream server is missing")).trimEnd('/')
        val user = source.username ?: error("Xtream username is missing")
        val pass = source.password ?: error("Xtream password is missing")
        return "$server/$kind/$user/$pass/$streamId.$extension"
    }
}
