# TVi PLAYER — Xtream Live Engine

Added in this stage:
- Xtream authentication via `player_api.php`
- Live categories
- Live streams
- Direct provider stream URL generation
- Provider connection remains separate from the OATEC control API
- Models tolerate common Xtream response fields

Next stage: persist Xtream live categories/streams into Room and expose them in the TV Live screen with Media3 playback, CH+/CH−, favorites and history.
