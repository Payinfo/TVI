# TVi PLAYER V1 — Movies / Series / EPG foundation

Added Xtream VOD/Series API models and repository plus an XMLTV parser foundation. Media traffic remains direct to the IPTV provider; OATEC is not a media proxy. Full EPG fetch/storage and detail/playback UI are next.
