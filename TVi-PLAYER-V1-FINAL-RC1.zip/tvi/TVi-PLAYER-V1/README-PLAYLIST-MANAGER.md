# TVi PLAYER V1 — Playlist Manager

Added in this build:
- TV-first landscape activity.
- Standard Player Playlist Manager.
- M3U URL import with validation/parser and local Room persistence.
- M3U file import through Android document picker.
- Xtream source creation (server/username/password) with local persistence.
- Playlist list and delete action.
- Imported M3U channels are stored locally and numbered in import order.
- IPTV provider traffic remains separate from OATEC control API.

Next: Xtream API catalog import (Live/Categories/Movies/Series), then Live TV receiver UI + Media3 playback.
