# TVi PLAYER V1 — Clean TV-first foundation

A new Android TV-first IPTV player project, rebuilt from zero. The old player UI/code is not used.

## Stage completed
- Landscape-first Android TV manifest.
- Remote/D-pad oriented UI foundation.
- OATEC Premium and Standard Player separation.
- Playlist Engine: M3U URL/file model, robust M3U parsing, Xtream model and stream URL generation.
- Room database foundation for playlists and normalized channels.
- OATEC networking kept separate from IPTV provider networking.

## Product rule
OATEC Premium is intended to become code-only for the customer. The supplied OATEC V14 backend currently exposes `/api/player/activate` requiring `email`, `code`, and `device_id`; therefore code-only activation is not falsely implemented until the backend endpoint is patched.

## Build
Open the project in Android Studio with an Android SDK 35 installation. Sync Gradle and build the `app` module.
