# TVi PLAYER V1 — Playlist Engine

Implemented in this stage:
- TV-first project remains landscape by default.
- M3U URL loading with redirects, UTF-8 BOM, CRLF/LF and common tvg/group/logo attributes.
- M3U channel normalization into a provider-independent Channel model.
- Xtream source model and direct stream URL builder.
- Playlist validation.
- Room persistence for playlists and parsed channels.
- Provider engine is independent from OATEC. OATEC config can feed a PlaylistSource later.

Important: the current OATEC backend in the supplied ZIP still requires `email + code + device_id` at `/api/player/activate`. The requested customer-facing "code only" flow therefore needs a small backend endpoint change before it can be truthfully enabled. This stage does not fake that behavior.
