# TVi PLAYER V1 — Content Organization

This stage adds persistent channel organization on top of the existing M3U/Xtream/EPG foundation:

- Favorites persisted in Room
- Watch history persisted in Room
- User categories persisted in Room
- Assign selected channels to user categories without changing provider playlists
- Manual channel number override
- Last/selected channel state
- Favorites-only filtering
- Room migration 1 -> 2
- TV landscape + Leanback metadata retained

Provider playlist data remains separate from user overlays. Changing favorites, category, or channel number does not rewrite the original M3U/Xtream source.

Build note: this environment does not contain a Gradle/Android SDK toolchain, so this source was not APK-compiled here.
